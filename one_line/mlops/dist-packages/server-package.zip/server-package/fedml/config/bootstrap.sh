# pip install fedml==0.7.15
#pip install --upgrade fedml
mkdir -p ~/.cache/fedml_data/MNIST
rm -rf ~/.cache/fedml_data/MNIST

### don't modify this part ###
echo "[FedML]Bootstrap Finished"
##############################
